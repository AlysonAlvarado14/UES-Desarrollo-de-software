#include <iostream>
using namespace std;

// Function to update elements of an array
void updateArray(int arr[], int size) {
    for (int i = 0; i < size; ++i) {
        arr[i] = arr[i] * 2; // Update each element by multiplying it by 2
    }
}

int main() {
    int myArray[] = {1, 2, 3, 4, 5};
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);

    cout << "Original array: ";
    for (int i = 0; i < arraySize; ++i) {
        cout << myArray[i] << " ";
    }
    cout << endl;

    updateArray(myArray, arraySize);

    cout << "Updated array: ";
    for (int i = 0; i < arraySize; ++i) {
        cout << myArray[i] << " ";
    }
    cout << endl;

    return 0;
}
