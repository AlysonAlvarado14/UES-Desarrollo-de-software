#include <iostream>
using namespace std;

struct Address {
    string street;
    string city;
    string country;

    void displayAddress() {
        cout << "Street: " << street << endl;
        cout << "City: " << city << endl;
        cout << "Country: " << country << endl;
    }
};

struct Person {
    string name;
    int age;
    Address address; // Nested struct

    void displayInfo() {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
        address.displayAddress();
    }
};

int main() {
    Person person1;
    person1.name = "Alice";
    person1.age = 30;
    person1.address.street = "123 Main St";
    person1.address.city = "Springfield";
    person1.address.country = "USA";

    person1.displayInfo();

    return 0;
}
