#include <iostream>
using namespace std;

// Function that takes an integer by value
void passByValue(int num) {
    num = num * 2; // This change won't affect the original variable
}

// Function that takes an integer by reference
void passByReference(int &num) {
    num = num * 2; // This change will affect the original variable
}

int main() {
    int a = 5;
    cout << "Initial value of a: " << a << endl;

    passByValue(a);
    cout << "Value of a after passByValue: " << a << endl; // Output will be 5

    passByReference(a);
    cout << "Value of a after passByReference: " << a << endl; // Output will be 10

    return 0;
}
