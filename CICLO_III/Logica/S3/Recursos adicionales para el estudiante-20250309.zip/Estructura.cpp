#include <iostream>
using namespace std;

struct Person {
    string name;
    int age;
    float height;

    void displayInfo() {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
        cout << "Height: " << height << " meters" << endl;
    }
};

int main() {
    Person person1;
    person1.name = "Alice";
    person1.age = 30;
    person1.height = 1.75;

    person1.displayInfo();

    return 0;
}
