#include <iostream>
/*
¿Qué hace este código?
Clase Fecha: Maneja un día, mes y año.
1. Sobrecarga del operador +:
2. Suma los días dados a la fecha actual.
3. Ajusta el mes y el año si el número de días excede el número de días del mes actual.
Uso en main():
4. Se crea una fecha base.
5. Se suma un número de días con +, haciendo que la fecha avance de manera automática.
6. Se muestra el resultado en formato día/mes/año.
*/
class Fecha {
private:
    int dia, mes, anio;

public:
    Fecha(int d, int m, int a) : dia(d), mes(m), anio(a) {} //Constructor

    // Función auxiliar para calcular días en un mes (asumiendo años no bisiestos)
    int diasEnMes(int mes) const {
        static const int diasPorMes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; //Cantidad de días por mes
        return diasPorMes[mes - 1];
    }

    // Sobrecarga del operador +
    /*"const" significa que la función garantiza que no cambiará los valores del objeto 
    original (Fecha). En su lugar, crea y devuelve una nueva instancia de Fecha con 
    la fecha ajustada. Si intentaras modificar variables miembro dentro de esta función, 
    el compilador generaría un error.*/
    Fecha operator+(int dias) const {
        int nuevoDia = dia + dias;
        int nuevoMes = mes;
        int nuevoAnio = anio;

        while (nuevoDia > diasEnMes(nuevoMes)) {
            nuevoDia -= diasEnMes(nuevoMes);
            nuevoMes++;

            if (nuevoMes > 12) {
                nuevoMes = 1;
                nuevoAnio++;
            }
        }

        return Fecha(nuevoDia, nuevoMes, nuevoAnio);
    }

    void mostrar() const {
        std::cout << dia << "/" << mes << "/" << anio << std::endl;
    }
};

int main() {
    Fecha hoy(27, 5, 2025);
    Fecha futuro = hoy + 10; // Suma de 10 días
    futuro.mostrar(); // Debería imprimir 6/6/2025
    return 0;
}
