#include <iostream>
/*En este ejemplo:
La clase Vector tiene dos componentes (x y y).
Se sobrecarga el operador + para sumar dos vectores y devolver un nuevo vector con la suma de sus componentes.
En main(), se crea y suma dos vectores con el operador sobrecargado. */
class Vector {
public:
    int x, y;

    Vector(int x = 0, int y = 0) : x(x), y(y) {}

    // Sobrecarga del operador +
    Vector operator+(const Vector& otro) const {
        return Vector(x + otro.x, y + otro.y);
    }

    void mostrar() const {
        std::cout << "(" << x << ", " << y << ")" << std::endl;
    }
};

int main() {
    Vector v1(3, 4);
    Vector v2(1, 2);
    Vector resultado = v1 + v2; // Uso del operador sobrecargado
    resultado.mostrar(); // Debería imprimir (4, 6)
    return 0;
}