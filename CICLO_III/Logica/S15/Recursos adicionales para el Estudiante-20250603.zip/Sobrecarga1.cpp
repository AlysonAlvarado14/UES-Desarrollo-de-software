#include <iostream>
/*En este ejemplo:
La clase Fraccion representa una fracción con un numerador y un denominador.
Se sobrecarga el operador * para multiplicar dos fracciones.
En main(), se multiplican dos fracciones y se muestra el resultado.*/
class Fraccion {
private:
    int numerador, denominador;

public:
    Fraccion(int num, int den) : numerador(num), denominador(den) {
        if (den == 0) {
            throw std::invalid_argument("El denominador no puede ser cero.");
        }
    }

    // Sobrecarga del operador *
    Fraccion operator*(const Fraccion& otra) const {
        return Fraccion(numerador * otra.numerador, denominador * otra.denominador);
    }

    void mostrar() const {
        std::cout << numerador << "/" << denominador << std::endl;
    }
};

int main() {
    Fraccion f1(2, 3);
    Fraccion f2(4, 5);
    Fraccion resultado = f1 * f2; // Uso del operador sobrecargado
    resultado.mostrar(); // Debería imprimir 8/15
    return 0;
}