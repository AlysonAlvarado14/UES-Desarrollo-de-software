#include <iostream>
#include <cstring>
/*
Explicación:
La clase Cadena gestiona una cadena de caracteres de manera dinámica.
Se sobrecarga el operador + para concatenar dos cadenas.
Se reserva memoria para la nueva cadena y se copia el contenido de ambas.
En main(), se crean dos objetos Cadena y se usa + para unirlas.*/
class Cadena {
private:
    char* cadena;
    int longitud;

public:
    Cadena(const char* texto = "") {
        longitud = std::strlen(texto);
        cadena = new char[longitud + 1];
        std::strcpy(cadena, texto);
    }

    // Sobrecarga del operador +
    Cadena operator+(const Cadena& otra) const {
        int nuevaLongitud = longitud + otra.longitud;
        char* nuevaCadena = new char[nuevaLongitud + 1];

        std::strcpy(nuevaCadena, cadena);
        std::strcat(nuevaCadena, otra.cadena);

        return Cadena(nuevaCadena);
    }

    void mostrar() const {
        std::cout << cadena << std::endl;
    }

    ~Cadena() {
        delete[] cadena;
    }
};

int main() {
    Cadena c1("Hola, ");
    Cadena c2("mundo!");
    Cadena resultado = c1 + c2; // Uso del operador sobrecargado
    resultado.mostrar(); // Debería imprimir "Hola, mundo!"
    return 0;
}