#include <iostream>
#include <string>
#include <cstring>  // For handling C-style strings

// Structure declaration
struct Person {
    std::string name;
    int age;
};

int main() {
    // Integer
    int integerVar = 42;

    // Float
    float floatVar = 3.14f;

    // Double
    double doubleVar = 2.718281828;

    // Character
    char charVar = 'A';

    // Boolean
    bool boolVar = true;

    // String (C++ string class)
    std::string stringVar = "Hello, C++!";

    // Char Array (C-style string)
    char cStringVar[] = "Hello, C-style string!";

    // Array
    int intArray[5] = {1, 2, 3, 4, 5};

    // Structure
    Person personVar = {"John Doe", 30};

    // Pointer
    int* pointerVar = &integerVar;

    // Output all variables
    std::cout << "Integer: " << integerVar << std::endl;
    std::cout << "Float: " << floatVar << std::endl;
    std::cout << "Double: " << doubleVar << std::endl;
    std::cout << "Character: " << charVar << std::endl;
    std::cout << "Boolean: " << boolVar << std::endl;
    std::cout << "String: " << stringVar << std::endl;
    std::cout << "C-style String: " << cStringVar << std::endl;
    
    std::cout << "Array elements: ";
    for (int i = 0; i < 5; ++i) {
        std::cout << intArray[i] << " ";
    }
    std::cout << std::endl;

    std::cout << "Person Name: " << personVar.name << ", Age: " << personVar.age << std::endl;
    std::cout << "Pointer (Address of integerVar): " << pointerVar << std::endl;
    std::cout << "Value at Address stored in Pointer: " << *pointerVar << std::endl;

    return 0;
}