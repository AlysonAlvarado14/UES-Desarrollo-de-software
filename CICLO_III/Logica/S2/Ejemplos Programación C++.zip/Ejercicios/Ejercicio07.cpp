#include <iostream>

/*struct LargeStruct {
    int a;
    double b;
    char c[50];
};*/
int main() {
    int var = 10;
    int* ptr = &var;
    // Tamaño de la variable en bytes
    std::cout << "Size of variable 'var': " << sizeof(var) << " bytes" << std::endl;
    // Tamaño del puntero en bytes
    std::cout << "Size of pointer 'ptr': " << sizeof(ptr) << " bytes" << std::endl;

/*  double var2 = 1234567.890;
    double* ptr2 = &var2;
    // Tamaño de la variable en bytes
    std::cout << "Size of variable 'var2': " << sizeof(var2) << " bytes" << std::endl;
    // Tamaño del puntero en bytes
    std::cout << "Size of pointer 'ptr2': " << sizeof(ptr2) << " bytes" << std::endl;

    LargeStruct var3;
    LargeStruct* ptr3 = &var3;

    // Tamaño de la variable en bytes
    std::cout << "Size of variable 'var3': " << sizeof(var3) << " bytes" << std::endl;
    // Tamaño del puntero en bytes
    std::cout << "Size of pointer 'ptr3': " << sizeof(ptr3) << " bytes" << std::endl;
*/
    return 0;
}

