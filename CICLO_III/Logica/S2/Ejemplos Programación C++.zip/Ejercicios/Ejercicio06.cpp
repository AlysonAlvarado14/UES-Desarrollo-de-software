/*#include <iostream>

int main() {
    int* ptr;   // Se declara un puntero pero no se inicializa

    // Tratamos de asignarle otro valor al puntero que no se ha inicializado
    *ptr = 42;  

    std::cout << "The value at ptr is: " << *ptr << std::endl;

    return 0;
}*/

/*#include <iostream>

int main() {
    int var = 0;
    int* ptr = &var;  // Initialize the pointer with the address of 'var'

    *ptr = 42;  // Assign a value to the memory location pointed to by 'ptr'

    std::cout << "The value at ptr is: " << *ptr << std::endl;

    return 0;
}*/