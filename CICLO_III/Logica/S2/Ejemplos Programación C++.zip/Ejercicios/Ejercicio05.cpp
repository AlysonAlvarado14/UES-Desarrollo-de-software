#include <iostream>

int main() {
    int var = 20;     // Creamos una variable de tipo entero
    int* ptr;        // Creamos una variable puntero que guardará la dirección de un entero

    ptr = &var;      // Almacena la dirección de memoria de la variable "var"

    // Imprime el valor de "var"
    std::cout << "The value of var: " << var << std::endl;

    // Imprime la dirección de memoria a donde apunta ptr (dirección de memoria de "var")
    std::cout << "The address of var: " << ptr << std::endl;

    // Imprime el valor almacenado en la dirección de memoria a la que apunta "ptr"
    std::cout << "The value at the address stored in ptr: " << *ptr << std::endl;

    return 0;
}