#include <iostream>

int main() {
    int num1, num2, suma;
    std::cout << "Ingresa el primer número: ";
    std::cin >> num1;
    std::cout << "Ingresa el segundo número: ";
    std::cin >> num2;
    suma = num1 + num2;
    std::cout << "La suma es: " << suma << std::endl;
    return 0;
}
