#include <iostream>
#include <cstring>
#include <string>

struct Person {
    std::string name;
    int age;
};

void increment(int* ptr) {
    (*ptr)++;
}

int main() {
    // Integer
    int num = 42;
    std::cout << "Integer: " << num << std::endl;

    // Float and Double
    float fnum = 3.14f;
    double dnum = 3.14159;
    std::cout << "Float: " << fnum << std::endl;
    std::cout << "Double: " << dnum << std::endl;

    // Character
    char ch = 'A';
    std::cout << "Character: " << ch << std::endl;

    // Boolean
    bool flag = true;
    std::cout << "Boolean: " << flag << std::endl;

    // String
    std::string greeting = "Hello, World!";
    std::cout << "String: " << greeting << std::endl;

    // Array
    int arr[5] = {1, 2, 3, 4, 5};
    std::cout << "Array elements: ";
    for (int i = 0; i < 5; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    // Structure
    Person person = {"John", 30};
    std::cout << "Name: " << person.name << ", Age: " << person.age << std::endl;

    // Pointer
    int* ptr = &num;
    std::cout << "Value of num: " << num << std::endl;
    std::cout << "Address of num: " << ptr << std::endl;
    std::cout << "Value at address stored in ptr: " << *ptr << std::endl;

    // Pointer as function parameter
    std::cout << "Before increment: " << num << std::endl;
    increment(&num);
    std::cout << "After increment: " << num << std::endl;

    // Char array (string)
    char charStr[] = "Hello, char array!";
    std::cout << "Char array: " << charStr << std::endl;

    // Concatenate char arrays
    char str1[50] = "Hello, ";
    char str2[] = "world!";
    strcat(str1, str2);
    std::cout << "Concatenated char array: " << str1 << std::endl;

    // Size of variables and pointers
    std::cout << "Size of int variable: " << sizeof(num) << " bytes" << std::endl;
    std::cout << "Size of int pointer: " << sizeof(ptr) << " bytes" << std::endl;
    std::cout << "Size of array: " << sizeof(arr) << " bytes" << std::endl;
    std::cout << "Size of struct variable: " << sizeof(person) << " bytes" << std::endl;

    return 0;
}
