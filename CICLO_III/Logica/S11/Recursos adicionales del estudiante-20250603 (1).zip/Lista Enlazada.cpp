#include <iostream>
using namespace std;

// Definimos la estructura del nodo
struct Node {
    int data;      // Dato que se almacenará en el nodo
    Node* next;    // Puntero al siguiente nodo
};

// Función para crear y agregar un nuevo nodo a la lista enlazada
void append(Node*& head, int value) { // Node*& head significa que se hace referencia a un puntero
    /*Explicación:
    Node* head:     Significa que es un puntero a un Nodo. Puede almacenar la dirección de un objeto Nodo.
    Node*& head:    Agregando el & significa que head es una referencia al puntero en si, no solo al valor 
                    hacia donde el puntero apunta.

    ¿Por qué usar Node*& head?
                    Cuando se pasa un puntero por referencia (Node*&), se permite modificaciones al puntero en 
                    sí mismo dentro de la función. Esto significa que la función puede cambiar hacia qué está apuntando 
                    el puntero, y esos cambios serán reflejados fuera de la función. */
                    
        Node* newNode = new Node;  // Creamos un nuevo nodo
        newNode->data = value;    // Asignamos el valor
        newNode->next = nullptr;  // Asignamos el siguiente nodo a null.

    if (head == nullptr) {
        head = newNode;       // Si la lista está vacía, newNode se convierte en el encabezado de la lista
    } else {
        Node* temp = head;    // Sino, la trasladamos hacia el final de la lista
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode; // Enlazamos el nuevo nodo al final
    }
}

// Función para mostrar la lista enlazada
void display(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "nullptr" << endl;
}

int main() {
    Node* head = nullptr; // Inicializamos una lista enlazada vacía

    // Agregamos nodos a la lista
    append(head, 10);
    append(head, 20);
    append(head, 30);

    // Mostramos la lista
    display(head);

    return 0;
}
