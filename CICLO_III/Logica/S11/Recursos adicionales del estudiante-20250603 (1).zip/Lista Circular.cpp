#include <iostream>
using namespace std;

// Definimos la estructura del nodo
struct Node {
    int data;      // Dato almacenado en el nodo
    Node* next;    // Puntero al siguiente nodo
};

// Función para agregar un nuevo nodo a la lista enlazada circular
void append(Node*& head, int value) {
    Node* newNode = new Node;  // Creamos un nuevo nodo
    newNode->data = value;    // Asignamos el valor
    newNode->next = nullptr;

    if (head == nullptr) {
        head = newNode;       // Si la lista está vacía, newNode se convierte en el encabezado de la lista
        newNode->next = head; // Enlazamos el nodo a sí mismo para formar un círculo
    } else {
        Node* temp = head;
        // Nos trasladamos hacia el último nodo
        while (temp->next != head) {
            temp = temp->next;
        }
        temp->next = newNode; // Enlazamos el último nodo al nuevo nodo
        newNode->next = head; // Enlazamos el nuevo nodo de regreso al encabezado de la lista
    }
}

// Función para mostrar la lista enlazada circular
void display(Node* head) {
    if (head == nullptr) {
        cout << "The list is empty!" << endl;
        return;
    }

    Node* temp = head;
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head); // Continúa hasta que hagamos un círculo de vuelta al encabezado de la lista
    cout << "(back to head)" << endl;
}

int main() {
    Node* head = nullptr; // Inicializamos una lista enlazada circular

    // Agregamos nodos a la lista
    append(head, 10);
    append(head, 20);
    append(head, 30);

    // Mostramos la lista
    display(head);

    return 0;
}
