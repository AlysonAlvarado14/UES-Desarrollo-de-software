#include <iostream>
using namespace std;

// Se define la estructura del nodo
struct Node {
    int data;       // Dato que se almacenará en el nodo
    Node* next;     // Puntero al siguiente nodo
    Node* prev;     // Puntero al nodo anterior
};

// Función para agregar un nodo a la lista doblemente enlazada
void append(Node*& head, int value) {
    Node* newNode = new Node;  // Creamos un nuevo nodo
    newNode->data = value;    // Asignamos el valor
    newNode->next = nullptr;  // El siguiente nodo es null si es el último nodo
    newNode->prev = nullptr;  // El anterior inicialmente es null

    if (head == nullptr) {
        head = newNode;       // Si la lista está vacía, newNode se convierte en el encabezado de la lista
    } else {
        Node* temp = head;    // Sino, trasladamos el nodo hacia el final de la lista
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode; // Enlazamos el nuevo nodo al final
        newNode->prev = temp; // Asignamos el puntero anterior al último nodo
    }
}

// Función para mostrar la lista hacia adelante
void displayForward(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "nullptr" << endl;
}

// Función para mostrar la lista hacia atrás
void displayBackward(Node* head) {
    Node* temp = head;
    // Nos trasladamos hacia el último nodo
    while (temp->next != nullptr) {
        temp = temp->next;
    }

    // Imprimir lista hacia atrás
    while (temp != nullptr) {
        cout << temp->data << " -> ";
        temp = temp->prev;
    }
    cout << "nullptr" << endl;
}

int main() {
    Node* head = nullptr; // Se inicializa una lista doblemente enlazada a null

    // Agregamos nodos a la lista
    append(head, 10);
    append(head, 20);
    append(head, 30);

    // Mostramos la lista
    cout << "Display Forward:" << endl;
    displayForward(head);

    cout << "Display Backward:" << endl;
    displayBackward(head);

    return 0;
}
