#include <iostream>
#include <fstream>

int main() {
    // Abre un archivo en modo de lectura / escritura
    std::fstream file("example.txt", std::ios::in | std::ios::out | std::ios::trunc);

    // Escribe algún texto en el archivo
    file << "¡Hola Mundo!";
    
    // Mueve el puntero "get" hacia el inicio del archivo
    file.seekg(0, std::ios::beg);

    // Lee y muestra el primer caracter
    char ch;
    file.get(ch);
    std::cout << "Primer Caracter: " << ch << std::endl;

    // Obtiene la posición actual del puntero "get"
    std::streampos getPos = file.tellg();
    std::cout << "Posicion actual del puntero 'get': " << getPos << std::endl;

    // Mueve el puntero "put" a la 6a posición
    file.seekp(7, std::ios::beg);
    file << "C++   ";

    // Obtiene la posición actual del puntero "put"
    std::streampos putPos = file.tellp();
    std::cout << "Posicion actual del puntero 'put': " << putPos << std::endl;

    // Cierra el archivo
    file.close();

    return 0;
}
