#include <iostream>
#include <fstream>

int main() {
    std::fstream file("example2.txt", std::ios::in | std::ios::out | std::ios::binary | std::ios::trunc);

    // Escribimos algunos datos en el archivo
    file << "Hola Mundo";

    // Movemos el puntero "get" 5 caracteres hacia atrás desde el final
    file.seekg(-5, std::ios::end);
    char ch;
    file.get(ch);
    std::cout << "Caracter 5 posiciones desde el final: " << ch << std::endl;

    // Mueve el puntero "put" 3 caracteres hacia atrás desde el final
    file.seekp(-5, std::ios::end);
    file << "C++";

    // Cierra el archivo
    file.close();

    return 0;
}
