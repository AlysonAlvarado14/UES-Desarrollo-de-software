#include <iostream>
#include <fstream>
#include <vector>

struct Data {
    int id;
    float value;
};

int main() {
    // Datos a escribir
    std::vector<Data> dataToWrite = {{1, 3.14}, {2, 2.71}, {3, 1.61}};

    // Escribiendo los datos en el archivo binario
    std::ofstream outFile("data.bin", std::ios::out | std::ios::binary);
    if (outFile.is_open()) {
        for (const auto& data : dataToWrite) {
            outFile.write(reinterpret_cast<const char*>(&data), sizeof(Data));
        }
        outFile.close();
        std::cout << "Datos escritos en archivo binario exitoso." << std::endl;
    } else {
        std::cerr << "Error en la apertura del archivo." << std::endl;
    }

    // Leer múltiples datos de un archivo binario
    std::vector<Data> dataRead;
    std::ifstream inFile("data.bin", std::ios::in | std::ios::binary);
    if (inFile.is_open()) {
        Data temp;
        while (inFile.read(reinterpret_cast<char*>(&temp), sizeof(Data))) {
            dataRead.push_back(temp);
        }
        inFile.close();
        std::cout << "Datos leídos del archivo binario:" << std::endl;
        for (const auto& data : dataRead) {
            std::cout << "ID: " << data.id << ", Value: " << data.value << std::endl;
        }
    } else {
        std::cerr << "Error al abrir el archivo." << std::endl;
    }

    return 0;
}
