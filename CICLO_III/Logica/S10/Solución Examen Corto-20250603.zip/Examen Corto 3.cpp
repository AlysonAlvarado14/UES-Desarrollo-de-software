#include <iostream>
#include <fstream>

struct Person {
    char name[50];
    int age;
};

int main() {
    Person p1 = {"Alice", 25};

    // Writing to a file
    std::ofstream outFile("person.dat", std::ios::binary);
    if (outFile.is_open()) {
        outFile.write(reinterpret_cast<char*>(&p1), sizeof(Person));
        outFile.close();
        std::cout << "Data written to file successfully.\n";
    } else {
        std::cerr << "Error opening file for writing.\n";
    }

    // Reading from a file
    Person p2;
    std::ifstream inFile("person.dat", std::ios::binary);
    if (inFile.is_open()) {
        inFile.read(reinterpret_cast<char*>(&p2), sizeof(Person));
        inFile.close();
        std::cout << "Data read from file successfully.\n";
        std::cout << "Name: " << p2.name << "\nAge: " << p2.age << '\n';
    } else {
        std::cerr << "Error opening file for reading.\n";
    }

    return 0;
}
