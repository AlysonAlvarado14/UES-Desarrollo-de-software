#include <iostream>
#include <fstream> // Required for file streams

int main() {
    // Using ofstream to write to a file
    std::ofstream outFile("LDP135-2025.txt");
    if (outFile.is_open()) {
        outFile << "Hello, this is a line of text." << std::endl;
        outFile << "Writing to a file using ofstream!" << std::endl;
        outFile.close();
    } else {
        std::cerr << "Unable to open file for writing." << std::endl;
    }

    // Using ifstream to read from a file
    std::ifstream inFile("LDP135-2025.txt");
    if (inFile.is_open()) {
        std::string line;
        while (std::getline(inFile, line)) {
            std::cout << line << std::endl; // Print each line to the console
        }
        inFile.close();
    } else {
        std::cerr << "Unable to open file for reading." << std::endl;
    }

    // Using fstream for both input and output
    std::fstream ioFile("LDP135-2025.txt", std::ios::in | std::ios::out | std::ios::app);
    if (ioFile.is_open()) {
        ioFile << "Appending this line using fstream!" << std::endl;
        ioFile.seekg(0); // Move the read pointer to the beginning of the file

        std::string line;
        while (std::getline(ioFile, line)) {
            std::cout << line << std::endl; // Print the updated file content
        }
        ioFile.close();
    } else {
        std::cerr << "Unable to open file for reading and writing." << std::endl;
    }

    return 0;
}

/*
ofstream: Used for writing data to a file (example.txt in this case).
ifstream: Used for reading data from a file.
fstream: Can be used for both reading and writing (or appending) to a file.

std::ios::in: This mode is used for input operations, i.e., reading from a file. It ensures the file is opened in read mode.
std::ios::out: This mode is used for output operations, i.e., writing to a file. It ensures the file is opened in write mode.
std::ios::app: This mode is used for appending data to the end of a file. When writing, the file pointer is moved to the end, 
and any new content is added without overwriting the existing data.
*/
