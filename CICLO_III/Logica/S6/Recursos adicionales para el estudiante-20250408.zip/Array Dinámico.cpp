#include <iostream>
using namespace std;

int main (){
    double *pd = new double[4];
    pd[0] = 7.5;
    pd[1] = 4.25;
    pd[2] = 0.45;
    pd[3] = 1.23;
    cout << " pd[1] es: " << pd[1] << "\n";
    pd++;
    cout << " Ahora pd[1] es: " << pd[1] << "\n";
    delete [] pd;
    return 0;
}

/*Si se ejecuta el programa, la salida es:
pd[1] es: 4.25
Ahora pd[1] es: 0.45*/