#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

// Estructura para representar un producto
struct Producto {
    string nombre;
    int cantidad;
    float precio;
};

// Función para agregar productos a la base de datos
void agregarProductos(Producto* productos, int numProductos, const string& nombreArchivo) {
    ofstream outFile(nombreArchivo, ios::app); // Abrir archivo en modo de añadir (append)
    if (outFile.is_open()) {
        for (int i = 0; i < numProductos; i++) {
            outFile << productos[i].nombre << ","
                    << productos[i].cantidad << ","
                    << fixed << setprecision(2) << productos[i].precio << endl;
        }
        outFile.close();
        cout << "\nProductos agregados al archivo correctamente.\n";
    } else {
        cout << "Error al abrir el archivo para escribir.\n";
    }
}

// Función para leer productos desde un archivo y mostrarlos
void mostrarProductos(const string& nombreArchivo) {
    ifstream inFile(nombreArchivo);
    if (inFile.is_open()) {
        string nombre;
        int cantidad;
        float precio;

        cout << "\nProductos en la Base de Datos:\n";
        cout << left << setw(20) << "Nombre"
             << setw(10) << "Cantidad"
             << setw(10) << "Precio" << endl;
        cout << setfill('-') << setw(40) << "-" << setfill(' ') << endl;

        while (getline(inFile, nombre, ',')) {
            inFile >> cantidad;
            inFile.ignore(1, ','); // Ignorar la coma
            inFile >> precio;
            inFile.ignore(1, '\n'); // Ignorar el salto de línea

            cout << left << setw(20) << nombre
                 << setw(10) << cantidad
                 << setw(10) << fixed << setprecision(2) << precio << endl;
        }
        inFile.close();
    } else {
        cout << "Error al abrir el archivo para lectura.\n";
    }
}

int main() {
    const string nombreArchivo = "productos.txt";
    int opcion;

    do {
        // Menú interactivo
        cout << "\nGestión de Productos\n";
        cout << "1. Agregar productos\n";
        cout << "2. Mostrar productos\n";
        cout << "3. Salir\n";
        cout << "Seleccione una opción: ";
        cin >> opcion;

        switch (opcion) {
            case 1: {
                int numProductos;
                cout << "Ingrese el número de productos a agregar: ";
                cin >> numProductos;
                cin.ignore(); // Limpiar el buffer de entrada

                // Crear un arreglo dinámico de productos
                Producto* productos = new Producto[numProductos];

                for (int i = 0; i < numProductos; i++) {
                    cout << "\nProducto " << i + 1 << ":\n";
                    cout << "Nombre: ";
                    getline(cin, productos[i].nombre);
                    cout << "Cantidad: ";
                    cin >> productos[i].cantidad;
                    cout << "Precio: ";
                    cin >> productos[i].precio;
                    cin.ignore(); // Limpiar el buffer de entrada
                }

                // Guardar productos en el archivo
                agregarProductos(productos, numProductos, nombreArchivo);

                // Liberar memoria dinámica
                delete[] productos;
                break;
            }
            case 2:
                // Leer y mostrar productos desde el archivo
                mostrarProductos(nombreArchivo);
                break;
            case 3:
                cout << "Saliendo del programa...\n";
                break;
            default:
                cout << "Opción inválida. Intente nuevamente.\n";
                break;
        }
    } while (opcion != 3);

    return 0;
}
