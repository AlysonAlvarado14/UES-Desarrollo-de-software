#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct Contacto {
    string nombres;
    string apellidos;
    string telefono;
    string correo;
};

void GuardarArchivo (string archivo, Contacto contactos[], int numContactos){
    // Guardar contactos en archivo de texto
    ofstream escribirArchivo(archivo);
    if (escribirArchivo.is_open()) {
        for (int i = 0; i < numContactos; i++) {
            escribirArchivo << contactos[i].nombres << ";";
            escribirArchivo << contactos[i].apellidos << ";";
            escribirArchivo << contactos[i].telefono << ";";
            escribirArchivo << contactos[i].correo << "\n";
        }
        escribirArchivo.close();
        cout << "Los contactos se han guardado en 'Contactos.txt'.\n";
    } else {
        cout << "Error al abrir el archivo.\n";
    }
}

void LeerArchivo(string archivo){
    // Leer Contactos
    Contacto contacto;
    ifstream leerArchivo(archivo);
    string linea;
    if(leerArchivo.is_open()){
        while(leerArchivo.good()){
            getline(leerArchivo, contacto.nombres, ';');
            getline(leerArchivo, contacto.apellidos, ';');
            getline(leerArchivo, contacto.telefono, ';');
            getline(leerArchivo, contacto.correo, '\n');
            if(!contacto.nombres.empty()){
                cout << "Nombres: " << contacto.nombres << endl;
                cout << "Apellidos: " << contacto.apellidos << endl;
                cout << "Telefono: " << contacto.telefono << endl;
                cout << "Correo: " << contacto.correo << endl;
                cout << "-------------------------" << endl;
            }
        }
        leerArchivo.close();
    }else{
        cout << "Error al abrir el archivo.\n";
    }
}

int main() {
    const int numContactos = 5;
    Contacto contactos[numContactos];

    // Recopilar información de contactos
    for (int i = 0; i < numContactos; i++) {
        cout << "Ingrese los datos del contacto " << i + 1 << ":\n";
        cout << "Nombres: ";
        getline(cin, contactos[i].nombres);
        cout << "Apellidos: ";
        getline(cin, contactos[i].apellidos);
        cout << "Teléfono: ";
        getline(cin, contactos[i].telefono);
        cout << "Correo Electrónico: ";
        getline(cin, contactos[i].correo);
    }
    GuardarArchivo("Contactos.txt",contactos,numContactos);
    LeerArchivo("Contactos.txt");
    return 0;
}