#include <iostream>
using namespace std;

class Animal {
public:
    void hacerSonido() { cout << "Hace un sonido" << endl; }
};

class Perro : public Animal { //Hereda de Animal
public:
    void hacerSonido() { cout << "Guau Guau" << endl; }
};

int main() {
    Perro miPerro;
    miPerro.hacerSonido(); // Output: Guau Guau
    return 0;
}
