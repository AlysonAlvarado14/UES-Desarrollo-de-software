#include <iostream>
using namespace std;

class Persona {
private:
    string nombre;

public:
    string apellido;

public:
    Persona(string n) { nombre = n; }
    string getNombre() { return nombre; }
};

int main() {
    Persona p("Juan");
    cout << p.getNombre() << endl; // Output: Juan
    return 0;
}
