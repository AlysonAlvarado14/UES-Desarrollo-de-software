#include <iostream>
using namespace std;

class Ave {
public:
    virtual void volar() { cout << "El ave está volando." << endl; }
};

class Loro : public Ave {
public:
    void volar() override { cout << "El loro vuela y habla." << endl; }
};

int main() {
    Ave* miAve = new Loro();
    miAve->volar(); // Output: El loro vuela y habla.
    delete miAve;
    return 0;
}
