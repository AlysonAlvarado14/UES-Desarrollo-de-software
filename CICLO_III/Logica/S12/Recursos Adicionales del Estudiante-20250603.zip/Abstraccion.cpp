#include <iostream>
using namespace std;

class Figura {
public:
    virtual void dibujar() = 0; // Método puramente virtual
};

class Circulo : public Figura {
public:
    void dibujar() override { cout << "Dibujando un círculo" << endl; }
};

int main() {
    Figura* figura = new Circulo();
    figura->dibujar(); // Output: Dibujando un círculo
    delete figura;
    return 0;
}
